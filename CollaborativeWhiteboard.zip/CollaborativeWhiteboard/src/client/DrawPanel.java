package client;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;

/**
 * Custom panel that acts as the whiteboard.
 * Now supports color, variable thickness, eraser, and clear.
 * It draws line segments and sends new lines to the server via a callback.
 */
public class DrawPanel extends JPanel {

    public interface DrawListener {
        void onNewLine(int x1, int y1, int x2, int y2, Color color, float strokeWidth);
    }

    private static class Line {
        int x1, y1, x2, y2;
        Color color;
        float stroke;

        Line(int x1, int y1, int x2, int y2, Color color, float stroke) {
            this.x1 = x1;
            this.y1 = y1;
            this.x2 = x2;
            this.y2 = y2;
            this.color = color;
            this.stroke = stroke;
        }
    }

    private final List<Line> lines = new ArrayList<>();
    private int lastX, lastY;
    private DrawListener drawListener;

    private Color currentColor = new Color(34, 197, 94); // soft green
    private float currentStroke = 3.0f;
    private boolean eraserMode = false;

    public DrawPanel() {
        setBackground(Color.WHITE);
        setDoubleBuffered(true);

        MouseAdapter mouseAdapter = new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                lastX = e.getX();
                lastY = e.getY();
            }

            @Override
            public void mouseDragged(MouseEvent e) {
                int x = e.getX();
                int y = e.getY();
                Color drawColor = eraserMode ? getBackground() : currentColor;
                float stroke = eraserMode ? currentStroke + 4.0f : currentStroke;
                addLineInternal(lastX, lastY, x, y, drawColor, stroke, true);
                lastX = x;
                lastY = y;
            }
        };

        addMouseListener(mouseAdapter);
        addMouseMotionListener(mouseAdapter);
    }

    public void setDrawListener(DrawListener listener) {
        this.drawListener = listener;
    }

    public void setCurrentColor(Color color) {
        this.currentColor = color;
        this.eraserMode = false;
    }

    public void setStrokeWidth(float strokeWidth) {
        this.currentStroke = Math.max(1.0f, strokeWidth);
    }

    public void setEraserMode(boolean eraserMode) {
        this.eraserMode = eraserMode;
    }

    public void clearBoard() {
        lines.clear();
        repaint();
    }

    // Called when we draw locally OR from server
    private void addLineInternal(int x1, int y1, int x2, int y2,
                                 Color color, float stroke,
                                 boolean notifyServer) {
        lines.add(new Line(x1, y1, x2, y2, color, stroke));
        repaint();

        if (notifyServer && drawListener != null) {
            drawListener.onNewLine(x1, y1, x2, y2, color, stroke);
        }
    }

    // Called by network layer when a DRAW message arrives
    public void addRemoteLine(int x1, int y1, int x2, int y2,
                              Color color, float stroke) {
        addLineInternal(x1, y1, x2, y2, color, stroke, false);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        // Optional subtle grid background
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                RenderingHints.VALUE_ANTIALIAS_ON);

        // light grid
        g2.setColor(new Color(240, 244, 248));
        for (int x = 0; x < getWidth(); x += 25) {
            g2.drawLine(x, 0, x, getHeight());
        }
        for (int y = 0; y < getHeight(); y += 25) {
            g2.drawLine(0, y, getWidth(), y);
        }

        // Draw strokes
        for (Line line : lines) {
            g2.setColor(line.color);
            g2.setStroke(new BasicStroke(
                    line.stroke,
                    BasicStroke.CAP_ROUND,
                    BasicStroke.JOIN_ROUND));
            g2.drawLine(line.x1, line.y1, line.x2, line.y2);
        }

        g2.dispose();
    }
}
