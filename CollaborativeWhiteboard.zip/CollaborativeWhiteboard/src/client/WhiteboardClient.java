package client;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.io.*;
import java.net.Socket;

/**
 * Client app:
 * - Connects to server
 * - Shows modern GUI with whiteboard + chat + tools
 * - Sends DRAW and CHAT (and CLEAR) messages to server
 * - Receives messages and updates UI in real time
 */
public class WhiteboardClient {

    private JFrame frame;
    private DrawPanel drawPanel;
    private JTextArea chatArea;
    private JTextField chatInput;

    private Socket socket;
    private BufferedReader in;
    private PrintWriter out;

    private String username;

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception ignored) {}
            new WhiteboardClient().start();
        });
    }

    private void start() {
        // Connection dialog
        JTextField ipField = new JTextField("127.0.0.1");
        JTextField userField = new JTextField("Student");

        JPanel panel = new JPanel(new GridLayout(0, 1, 6, 6));
        panel.setBorder(new EmptyBorder(10, 10, 10, 10));
        panel.add(new JLabel("Server IP:"));
        panel.add(ipField);
        panel.add(new JLabel("Username:"));
        panel.add(userField);

        int result = JOptionPane.showConfirmDialog(
                null, panel, "Connect to Whiteboard Server",
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

        if (result != JOptionPane.OK_OPTION) {
            System.exit(0);
        }

        String serverIp = ipField.getText().trim();
        username = userField.getText().trim();
        if (username.isEmpty()) {
            username = "Student";
        }

        // Connect to server
        try {
            socket = new Socket(serverIp, 5000);
            in = new BufferedReader(
                    new InputStreamReader(socket.getInputStream()));
            out = new PrintWriter(
                    new OutputStreamWriter(socket.getOutputStream()), true);

            // Send JOIN message
            out.println("JOIN|" + username);

            // Setup GUI
            initUI();

            // Start reading thread
            new Thread(this::listenToServer).start();

        } catch (IOException e) {
            JOptionPane.showMessageDialog(null,
                    "Could not connect to server: " + e.getMessage(),
                    "Connection Error", JOptionPane.ERROR_MESSAGE);
            System.exit(1);
        }
    }

    private void initUI() {
        frame = new JFrame("CollabBoard – Interactive Classroom | " + username);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1200, 750);
        frame.setLocationRelativeTo(null);
        frame.getContentPane().setLayout(new BorderLayout());

        Color bgDark = new Color(15, 23, 42);      // deep slate
        Color bgHeader = new Color(30, 64, 175);   // indigo
        Color bgPanel = new Color(22, 30, 56);
        Color accent = new Color(56, 189, 248);    // cyan
        Color textLight = new Color(241, 245, 249);

        // ---------- HEADER ----------
        JPanel header = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_RENDERING,
                        RenderingHints.VALUE_RENDER_QUALITY);
                GradientPaint gp = new GradientPaint(
                        0, 0, bgHeader,
                        getWidth(), getHeight(), new Color(8, 47, 73));
                g2.setPaint(gp);
                g2.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        header.setLayout(new BorderLayout());
        header.setBorder(new EmptyBorder(10, 18, 10, 18));

        JLabel title = new JLabel("CollabBoard");
        title.setForeground(textLight);
        title.setFont(title.getFont().deriveFont(Font.BOLD, 22f));

        JLabel subtitle = new JLabel("Live collaborative whiteboard & class chat");
        subtitle.setForeground(new Color(191, 219, 254));
        subtitle.setFont(subtitle.getFont().deriveFont(13f));

        JPanel titleBox = new JPanel();
        titleBox.setOpaque(false);
        titleBox.setLayout(new BoxLayout(titleBox, BoxLayout.Y_AXIS));
        titleBox.add(title);
        titleBox.add(Box.createVerticalStrut(2));
        titleBox.add(subtitle);

        JLabel userLabel = new JLabel(" Connected as " + username + "  ");
        userLabel.setForeground(textLight);
        userLabel.setFont(userLabel.getFont().deriveFont(Font.PLAIN, 13f));
        userLabel.setIcon(UIManager.getIcon("OptionPane.informationIcon"));

        header.add(titleBox, BorderLayout.WEST);
        header.add(userLabel, BorderLayout.EAST);

        frame.add(header, BorderLayout.NORTH);

        // ---------- DRAW PANEL & TOOLBAR ----------
        drawPanel = new DrawPanel();
        drawPanel.setPreferredSize(new Dimension(800, 700));
        drawPanel.setBorder(BorderFactory.createCompoundBorder(
                new EmptyBorder(12, 12, 12, 12),
                BorderFactory.createLineBorder(new Color(30, 64, 175), 2, true)
        ));

        // When user draws, send DRAW message to server
        drawPanel.setDrawListener((x1, y1, x2, y2, color, stroke) -> {
            if (out != null) {
                int rgb = color.getRGB();
                out.println("DRAW|" + x1 + "|" + y1 + "|" + x2 + "|" + y2 + "|" + rgb + "|" + stroke);
            }
        });

        JPanel toolsPanel = createToolsPanel(bgPanel, accent);

        JPanel leftSide = new JPanel(new BorderLayout());
        leftSide.setBackground(bgDark);
        leftSide.add(toolsPanel, BorderLayout.WEST);
        leftSide.add(drawPanel, BorderLayout.CENTER);

        // ---------- CHAT PANEL ----------
        JPanel chatPanel = new JPanel(new BorderLayout());
        chatPanel.setBackground(bgDark);
        chatPanel.setBorder(new EmptyBorder(12, 8, 12, 12));
        chatPanel.setPreferredSize(new Dimension(340, 700));

        JPanel chatCard = new JPanel(new BorderLayout(8, 8));
        chatCard.setBackground(new Color(15, 23, 42));
        chatCard.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(30, 64, 175), 1, true),
                new EmptyBorder(10, 12, 12, 12)
        ));

        JLabel chatLabel = new JLabel("Class Chat");
        chatLabel.setForeground(textLight);
        chatLabel.setFont(chatLabel.getFont().deriveFont(Font.BOLD, 15f));

        JLabel chatHint = new JLabel("Ask doubts, share links, react in real time.");
        chatHint.setForeground(new Color(148, 163, 184));
        chatHint.setFont(chatHint.getFont().deriveFont(11f));

        JPanel chatHeader = new JPanel();
        chatHeader.setOpaque(false);
        chatHeader.setLayout(new BoxLayout(chatHeader, BoxLayout.Y_AXIS));
        chatHeader.add(chatLabel);
        chatHeader.add(chatHint);

        chatArea = new JTextArea();
        chatArea.setEditable(false);
        chatArea.setLineWrap(true);
        chatArea.setWrapStyleWord(true);
        chatArea.setForeground(new Color(226, 232, 240));
        chatArea.setBackground(new Color(15, 23, 42));
        chatArea.setFont(chatArea.getFont().deriveFont(13f));
        chatArea.setBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4));
        JScrollPane chatScroll = new JScrollPane(chatArea);
        chatScroll.setBorder(BorderFactory.createEmptyBorder());

        chatInput = new JTextField();
        chatInput.setFont(chatInput.getFont().deriveFont(13f));
        chatInput.setMargin(new Insets(4, 6, 4, 6));
        chatInput.setBackground(new Color(15, 23, 42));
        chatInput.setForeground(textLight);
        chatInput.setCaretColor(textLight);
        chatInput.setBorder(BorderFactory.createLineBorder(new Color(51, 65, 85), 1, true));
        chatInput.addActionListener(e -> sendChatMessage());

        JButton sendBtn = new JButton("Send");
        sendBtn.setFocusPainted(false);
        sendBtn.setBackground(accent);
        sendBtn.setForeground(Color.BLACK);
        sendBtn.setFont(sendBtn.getFont().deriveFont(Font.BOLD, 12f));
        sendBtn.addActionListener(e -> sendChatMessage());

        JPanel inputPanel = new JPanel(new BorderLayout(6, 6));
        inputPanel.setOpaque(false);
        inputPanel.add(chatInput, BorderLayout.CENTER);
        inputPanel.add(sendBtn, BorderLayout.EAST);

        chatCard.add(chatHeader, BorderLayout.NORTH);
        chatCard.add(chatScroll, BorderLayout.CENTER);
        chatCard.add(inputPanel, BorderLayout.SOUTH);

        chatPanel.add(chatCard, BorderLayout.CENTER);

        // ---------- MAIN SPLIT ----------
        JSplitPane splitPane = new JSplitPane(
                JSplitPane.HORIZONTAL_SPLIT,
                leftSide, chatPanel);
        splitPane.setResizeWeight(0.7);
        splitPane.setBorder(null);
        frame.add(splitPane, BorderLayout.CENTER);

        frame.getContentPane().setBackground(bgDark);
        frame.setVisible(true);
    }

    private JPanel createToolsPanel(Color bgPanel, Color accent) {
        JPanel tools = new JPanel();
        tools.setBackground(bgPanel);
        tools.setBorder(new EmptyBorder(18, 10, 18, 10));
        tools.setLayout(new BoxLayout(tools, BoxLayout.Y_AXIS));

        JLabel toolsTitle = new JLabel(" Tools");
        toolsTitle.setForeground(new Color(209, 213, 219));
        toolsTitle.setFont(toolsTitle.getFont().deriveFont(Font.BOLD, 13f));

        tools.add(toolsTitle);
        tools.add(Box.createVerticalStrut(10));

        // Color palette
        JPanel palette = new JPanel();
        palette.setOpaque(false);
        palette.setLayout(new GridLayout(2, 3, 4, 4));

        Color[] colors = new Color[] {
                new Color(56, 189, 248), // cyan
                new Color(34, 197, 94),  // green
                new Color(249, 115, 22), // orange
                new Color(239, 68, 68),  // red
                new Color(129, 140, 248),// indigo
                new Color(248, 250, 252) // white-ish
        };

        for (Color c : colors) {
            JButton colorBtn = new JButton();
            colorBtn.setBackground(c);
            colorBtn.setBorder(BorderFactory.createLineBorder(Color.DARK_GRAY, 1));
            colorBtn.setPreferredSize(new Dimension(22, 22));
            colorBtn.setFocusPainted(false);
            colorBtn.addActionListener(e -> {
                drawPanel.setCurrentColor(c);
            });
            palette.add(colorBtn);
        }

        tools.add(palette);
        tools.add(Box.createVerticalStrut(15));

        // Pen / Eraser
        JToggleButton penButton = new JToggleButton("Pen");
        penButton.setSelected(true);
        JToggleButton eraserButton = new JToggleButton("Eraser");

        penButton.setFocusPainted(false);
        eraserButton.setFocusPainted(false);

        penButton.addActionListener(e -> {
            if (penButton.isSelected()) {
                eraserButton.setSelected(false);
                drawPanel.setEraserMode(false);
            } else {
                penButton.setSelected(true); // always keep one selected
            }
        });

        eraserButton.addActionListener(e -> {
            if (eraserButton.isSelected()) {
                penButton.setSelected(false);
                drawPanel.setEraserMode(true);
            } else {
                eraserButton.setSelected(true);
            }
        });

        JPanel penEraserRow = new JPanel(new GridLayout(1, 2, 5, 0));
        penEraserRow.setOpaque(false);
        penEraserRow.add(penButton);
        penEraserRow.add(eraserButton);

        tools.add(penEraserRow);
        tools.add(Box.createVerticalStrut(15));

        // Thickness slider
        JLabel thicknessLabel = new JLabel(" Stroke width");
        thicknessLabel.setForeground(new Color(209, 213, 219));
        thicknessLabel.setFont(thicknessLabel.getFont().deriveFont(12f));
        tools.add(thicknessLabel);
        tools.add(Box.createVerticalStrut(4));

        JSlider thicknessSlider = new JSlider(1, 12, 3);
        thicknessSlider.setOpaque(false);
        thicknessSlider.addChangeListener(e -> {
            int v = thicknessSlider.getValue();
            drawPanel.setStrokeWidth(v);
        });
        tools.add(thicknessSlider);
        tools.add(Box.createVerticalStrut(15));

        // Clear + focus buttons
        JButton clearBtn = new JButton("Clear board");
        clearBtn.setFocusPainted(false);
        clearBtn.setBackground(new Color(30, 64, 175));
        clearBtn.setForeground(Color.WHITE);
        clearBtn.setFont(clearBtn.getFont().deriveFont(Font.BOLD, 11f));
        clearBtn.addActionListener(e -> {
            drawPanel.clearBoard();
            if (out != null) {
                out.println("CLEAR|");
            }
        });

        JButton focusBtn = new JButton("Focus mode");
        focusBtn.setFocusPainted(false);
        focusBtn.setBackground(new Color(55, 65, 81));
        focusBtn.setForeground(Color.WHITE);
        focusBtn.setFont(focusBtn.getFont().deriveFont(11f));
        focusBtn.addActionListener(e -> {
            // Toggle chat visibility
            boolean isMax = frame.getExtendedState() == JFrame.MAXIMIZED_BOTH;
            frame.setExtendedState(isMax ? JFrame.NORMAL : JFrame.MAXIMIZED_BOTH);
        });

        tools.add(clearBtn);
        tools.add(Box.createVerticalStrut(6));
        tools.add(focusBtn);
        tools.add(Box.createVerticalGlue());

        return tools;
    }

    private void sendChatMessage() {
        String text = chatInput.getText().trim();
        if (!text.isEmpty() && out != null) {
            out.println("CHAT|" + username + "|" + text);
            chatInput.setText("");
        }
    }

    private void listenToServer() {
        try {
            String line;
            while ((line = in.readLine()) != null) {
                final String msg = line;
                SwingUtilities.invokeLater(() -> handleServerMessage(msg));
            }
        } catch (IOException e) {
            SwingUtilities.invokeLater(() -> {
                JOptionPane.showMessageDialog(frame,
                        "Disconnected from server.",
                        "Connection Lost",
                        JOptionPane.WARNING_MESSAGE);
                frame.dispose();
                System.exit(0);
            });
        }
    }

    private void handleServerMessage(String msg) {
        if (msg.startsWith("CHAT|")) {
            String[] parts = msg.split("\\|", 3);
            if (parts.length == 3) {
                String fromUser = parts[1];
                String text = parts[2];
                chatArea.append(fromUser + ": " + text + "\n");
            }
        } else if (msg.startsWith("DRAW|")) {
            String[] parts = msg.split("\\|");
            // Backward compatible: if no color/thickness, use defaults
            if (parts.length >= 5) {
                try {
                    int x1 = Integer.parseInt(parts[1]);
                    int y1 = Integer.parseInt(parts[2]);
                    int x2 = Integer.parseInt(parts[3]);
                    int y2 = Integer.parseInt(parts[4]);

                    Color color = Color.BLACK;
                    float stroke = 2.0f;

                    if (parts.length >= 7) {
                        int rgb = Integer.parseInt(parts[5]);
                        color = new Color(rgb, true);
                        stroke = Float.parseFloat(parts[6]);
                    }

                    drawPanel.addRemoteLine(x1, y1, x2, y2, color, stroke);
                } catch (NumberFormatException ignored) {}
            }
        } else if (msg.startsWith("CLEAR|")) {
            drawPanel.clearBoard();
        }
    }
}
