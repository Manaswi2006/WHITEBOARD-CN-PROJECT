package server;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

/**
 * Simple multi-client server for chat + whiteboard.
 * Protocol:
 *   CHAT|username|message
 *   DRAW|x1|y1|x2|y2
 * The server just broadcasts messages to all clients.
 */
public class WhiteboardServer {

    private static final int PORT = 5000;

    // All connected clients
    private static final Set<ClientHandler> clients =
            Collections.synchronizedSet(new HashSet<>());

    public static void main(String[] args) {
        System.out.println("Whiteboard server starting on port " + PORT + "...");
        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            while (true) {
                Socket socket = serverSocket.accept();
                System.out.println("New client connected: " + socket.getRemoteSocketAddress());
                ClientHandler handler = new ClientHandler(socket);
                clients.add(handler);
                new Thread(handler).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Broadcast a message to all clients
    public static void broadcast(String message, ClientHandler exclude) {
        synchronized (clients) {
            for (ClientHandler client : clients) {
                if (client != exclude) {
                    client.sendMessage(message);
                }
            }
        }
    }

    // Remove a client from the set
    public static void removeClient(ClientHandler client) {
        clients.remove(client);
    }

    // Inner class to handle one client
    private static class ClientHandler implements Runnable {
        private final Socket socket;
        private BufferedReader in;
        private PrintWriter out;
        private String username = "Anonymous";

        public ClientHandler(Socket socket) {
            this.socket = socket;
        }

        public void sendMessage(String msg) {
            out.println(msg);
        }

        @Override
        public void run() {
            try {
                in = new BufferedReader(
                        new InputStreamReader(socket.getInputStream()));
                out = new PrintWriter(
                        new OutputStreamWriter(socket.getOutputStream()), true);

                // First line from client should be JOIN|username
                String joinLine = in.readLine();
                if (joinLine != null && joinLine.startsWith("JOIN|")) {
                    String[] parts = joinLine.split("\\|", 2);
                    if (parts.length == 2 && !parts[1].isEmpty()) {
                        username = parts[1];
                    }
                }

                System.out.println("User joined: " + username);
                broadcast("CHAT|SERVER|" + username + " joined the session.", this);

                String line;
                while ((line = in.readLine()) != null) {
                    // Just log and broadcast
                    if (line.startsWith("CHAT|") || line.startsWith("DRAW|")) {
                        broadcast(line, this);
                    }
                }
            } catch (IOException e) {
                System.out.println("Connection lost with " + username);
            } finally {
                WhiteboardServer.removeClient(this);
                broadcast("CHAT|SERVER|" + username + " left the session.", this);
                try {
                    socket.close();
                } catch (IOException ignored) {}
            }
        }
    }
}
